# Shexter - Shell Texter Client

A cross-platform client for texting through your Android phone from the command line.

[Download the app here](https://github.com/tetchel/Shexter/raw/master/shexter/app/app-release.apk)

## Settings
Settings (right now only your phone IP address is configurable) is stored in `$XDG_CONFIG_DIR/shexter/` on Linux, or `$User\AppData\Local\shexter` on Windows, in `shexter.ini`.
